package com.zheng.home.injection


import javax.inject.Qualifier

@Qualifier @Retention annotation class ActivityContext
