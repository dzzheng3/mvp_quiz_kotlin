package com.zheng.home.util

object DefaultConfig {
    //The api level that Roboelectric will use to run the unit tests
    val EMULATE_SDK = 24
}